# CoSc 350 - Task 6b - Left-Arrow
#!/bin/usr/bash

#!/bin/bash

read -p "Enter base width of arrow head, value must be odd x >= 3" base

if [ -z $base ]; then
    echo "ERROR: entry was empty"
    exit 1
elif [ $base -lt 3 ]; then
    echo "cannot be less than 3"
    exit 1
fi

a=$base%2
b=1

read -p "Enter a tail length of the arrow, must be a positive integer" atail

if [ -z $atail ]; then
    echo "ERROR: entry was empty"
    exit 1
elif [ $atail -le 0 ]; then
    echo "Tail must be positive"
    exit 1
fi

while [[ "$b" -lt "$base" ]]; do
    spaces=$((width-b))

    for i in $(seq 1 $spaces); do
        echo -n " "
    done

    for j in $(seq 1 $b); do
        echo -n "*"
    done
    b=$b+2
    echo
done

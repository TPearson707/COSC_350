#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_SIZE 1
#define INT_BUFFER_SIZE 4
#define STR_SIZE 1

void err_sys(const char* str) {
    write(2, str, strlen(str));
    exit(1);
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        err_sys("Usage: ./program input_file output_file\n");
    }

    int inFileDes, outFileDes, nbyte;
    char buffer[BUFFER_SIZE];
    char encrypted_buffer[INT_BUFFER_SIZE];
    umask(0);

    // Open input file in read-only mode
    inFileDes = open(argv[1], O_RDONLY);
    if (inFileDes < 0) {
        err_sys("ERROR opening input file!\n");
    }

    outFileDes = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (outFileDes < 0) {
        close(inFileDes);
        err_sys("ERROR opening/creating output file!\n");
    }

    while ((nbyte = read(inFileDes, buffer, BUFFER_SIZE)) > 0) {
        int ascii_value = (int)(unsigned char)buffer[0];

        int len = 0;
        int temp = ascii_value;

        if (ascii_value == 0) {
            encrypted_buffer[len++] = '0';
        } else {

            while (temp > 0) {
                encrypted_buffer[len++] = (temp % 10) + '0';
                temp /= 10;
            }
        }

        for (int i = 0; i < len / 2; i++) {
            char temp_char = encrypted_buffer[i];
            encrypted_buffer[i] = encrypted_buffer[len - 1 - i];
            encrypted_buffer[len - 1 - i] = temp_char;
        }

        encrypted_buffer[len++] = '\n';

        if (write(outFileDes, encrypted_buffer, len) != len) {
            err_sys("WRITE ERROR!\n");
        }
    }

    if (nbyte < 0) {
        err_sys("READ ERROR!\n");
    }

    close(inFileDes);
    close(outFileDes);

    return 0;
}

